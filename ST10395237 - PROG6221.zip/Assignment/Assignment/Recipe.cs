﻿using System;
using System.Collections.Generic;

namespace RecipeApplication
{
    public class Recipe
    {
        private List<Ingredient> ingredients;
        public Steps RecipeSteps { get; set; }

        public Recipe()
        {
            ingredients = new List<Ingredient>();
            RecipeSteps = new Steps();
        }

        public void AddIngredient(Ingredient ingredient)
        {
            ingredients.Add(ingredient);
        }

        public void ClearIngredients()
        {
            ingredients.Clear();
        }

        public void DisplayIngredients()
        {
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }
        }

        public void ScaleIngredients(double factor)
        {
            foreach (var ingredient in ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void ResetIngredientQuantities()
        {
            foreach (var ingredient in ingredients)
            {
                ingredient.ResetQuantity();
            }
        }

        public void ClearData()
        {
            ClearIngredients();
            RecipeSteps.ClearSteps();
            Console.WriteLine("All data cleared.");
        }
    }
}
