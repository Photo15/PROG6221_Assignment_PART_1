﻿using System;

namespace RecipeApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            // recipe method
            Recipe recipe = new Recipe();
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("*************************************************************************************");
                Console.WriteLine("Recipe Menu");
                Console.WriteLine("*************************************************************************************");
                Console.WriteLine("1. Enter Recipe Details");
                Console.WriteLine("2. Display Recipe");
                Console.WriteLine("3. Scale Recipe");
                Console.WriteLine("4. Reset Quantities");
                Console.WriteLine("5. Clear All Data");
                Console.WriteLine("6. Exit");
                Console.WriteLine("*************************************************************************************");
                Console.Write("Enter your choice: ");
                string choice = Console.ReadLine();


                // decisioons method to redirect the user according to their choice
                switch (choice)
                {
                    case "1":
                        EnterRecipeDetails(recipe); 
                        break;
                    case "2":
                        DisplayRecipe(recipe); 
                        break;
                    case "3":
                        ScaleRecipe(recipe); 
                        break;
                    case "4":
                        ResetQuantities(recipe); 
                        break;
                    case "5":
                        recipe.ClearData(); 
                        break;
                    case "6":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;

                }
            }
        }

        static void EnterRecipeDetails(Recipe recipe)
        {
            Console.Write("Enter the number of ingredients: ");
            int ingredientCount = Convert.ToInt32(Console.ReadLine());

            // Clear existing ingredients

            recipe.ClearIngredients(); 

            for (int i = 0; i < ingredientCount; i++)
            {
                Console.WriteLine($"Enter details for Ingredient {i + 1}:");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                Console.Write("Quantity: ");
                double quantity = Convert.ToDouble(Console.ReadLine());
                Console.Write("Unit of Measurement: ");
                string unit = Console.ReadLine();

                recipe.AddIngredient(new Ingredient(name, quantity, unit));
            }

            Console.Write("Enter the number of steps: ");
            int stepCount = Convert.ToInt32(Console.ReadLine());

            // Clear existing steps

            recipe.RecipeSteps.ClearSteps(); 

            for (int i = 0; i < stepCount; i++)
            {
                Console.WriteLine($"Enter Step {i + 1}:");
                string step = Console.ReadLine();
                recipe.RecipeSteps.AddStep(step);
            }

            Console.WriteLine("Recipe details entered successfully!");
        }

        static void DisplayRecipe(Recipe recipe)
        {
            Console.WriteLine("Recipe Details:");
            Console.WriteLine("Ingredients:");

            // Display ingredients using Recipe's method

            recipe.DisplayIngredients(); 

            Console.WriteLine("Steps:");
            foreach (var step in recipe.RecipeSteps.StepList)
            {
                Console.WriteLine(step);
            }
        }

        static void ScaleRecipe(Recipe recipe)
        {
            Console.Write("Enter the scaling factor (0.5, 2, or 3): ");
            double factor = Convert.ToInt32(Console.ReadLine());

            // Scale ingredients using Recipe's method

            recipe.ScaleIngredients(factor); 
            Console.WriteLine("Recipe scaled successfully!");
        }

        static void ResetQuantities(Recipe recipe)
        {
            // Reset quantities using Recipe's method
            recipe.ResetIngredientQuantities(); 
            Console.WriteLine("Quantities reset to original values.");
        }
    }
}
