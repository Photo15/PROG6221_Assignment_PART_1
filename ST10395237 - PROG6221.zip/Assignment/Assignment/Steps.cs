﻿using System.Collections.Generic;

namespace RecipeApplication
{
    public class Steps
    {
        public List<string> StepList { get; set; }

        public Steps()
        {
            StepList = new List<string>();
        }

        public void AddStep(string step)
        {
            StepList.Add(step);
        }

        public void ClearSteps()
        {
            StepList.Clear();
        }
    }
}
